# HijriGold

تطبيق التقويم الهجري — أخضر وذهبي.

## البناء السحابي من الجوال

المشروع مجهز للبناء عبر GitHub Actions ولا يحتاج Android Studio أو كمبيوتر.

1. أنشئ مستودعًا جديدًا على GitHub باسم `HijriGold`.
2. ارفع محتويات هذا المجلد إلى المستودع، مع الحفاظ على مجلد `.github/workflows`.
3. افتح تبويب **Actions** في المستودع.
4. اختر **Build HijriGold APK** ثم **Run workflow**.
5. بعد نجاح البناء افتح التشغيل الناجح، وستجد قسم **Artifacts**.
6. نزّل `HijriGold-debug-apk`، وفك الضغط عنه لتحصل على `app-debug.apk`.
7. انقل APK إلى هاتف Android وثبّته.

## متطلبات البناء

- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- compileSdk 34
- minSdk 26

التطبيق يعمل محليًا دون إنترنت ولا يطلب صلاحيات إضافية بحسب إعدادات المشروع الحالية.
