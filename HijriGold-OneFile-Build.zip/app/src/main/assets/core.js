const DAY=86400000;
const S={adj:0,ar:true};
try{S.adj=+(localStorage.getItem('adj')||0);S.ar=localStorage.getItem('ar')!=='0';}catch(e){}
const fmt=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'numeric',year:'numeric'});
const addDays=(d,n)=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+n,12);
function hij(dt){const p={};fmt.formatToParts(addDays(dt,S.adj)).forEach(x=>{p[x.type]=+x.value});return{y:p.year,m:p.month,d:p.day};}
const firstOf=dt=>addDays(dt,-(hij(dt).d-1));
function h2g(y,m,d){
  const e=new Date(Date.UTC(622,6,16)+((y-1)*354.367+(m-1)*29.53+d-1)*DAY);
  let dt=new Date(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate(),12);
  const t=(y*13+m)*40+d;
  for(let i=0;i<120;i++){const h=hij(dt),k=(h.y*13+h.m)*40+h.d;if(k===t)return dt;dt=addDays(dt,k<t?1:-1);}
  return null;
}
if(typeof module!=='undefined')module.exports={S,hij,h2g,firstOf,addDays};
